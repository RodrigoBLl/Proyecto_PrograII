#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <iostream>//Solo para los datos. Es m�s c�moda la impresi�n
#include <conio.h>
#include <windows.h>

#define MAX_SEN 100
#define MAX_LENGTH 100

#define MAX_WORDS 100
#define MAX_WORD_LEN 50

using namespace std;
struct users{
	char name[50];
	char pass[50];
	struct users *next;
};

struct users *first = NULL, *last = NULL;

struct Nodo {
    char nom[20];
    int score;
    struct Nodo *sig;
};



void categorias();
void scoreSen();
void mainMenu();
void scoreOrder();
void gameMenu();


int validaEntero(const char mensaje[]){
	int continuar=0;
	int entero=0;
	
	do{
		printf("\n%s",mensaje);
		continuar = scanf("%d", &entero);
		fflush(stdin);
	}while (continuar != 1);
	
	return entero;
}


void validaCadena(const char mensaje[], char cadena[]){
	bool bandera = true;
	while(bandera){
		printf("\n%s", mensaje);
		scanf("%[^\n]", cadena);
		fflush(stdin);
		if(strlen(cadena)>40){
			continue;
		}else{
			for(int i=0; i<strlen(cadena); i++){
				if( isalpha(cadena[i]) || cadena[i]==' ' || cadena[i]=='@'){
					if(i == (strlen(cadena)-1)){
						bandera=false;
						}
					}else{
						break;
				}				
			}
		}
	}
}

void orderword(){
    system("cls");
    char sen[MAX_SEN][MAX_LENGTH];
    char ans[MAX_SEN][MAX_LENGTH];
    char playerAns[MAX_SEN][MAX_LENGTH];
    int senCount = 0;
   
    FILE* senFile = fopen("ordenar.txt", "r");
    if (senFile == NULL) {
        printf("Error opening file.\n");
        return ;
    }
   
    FILE* ansFile = fopen("ordenarRes.txt", "r");
    if (ansFile == NULL) {
        printf("Error opening file.\n");
        return ;
    }
   
    while (fgets(sen[senCount], MAX_LENGTH, senFile) != NULL) {
        sen[senCount][strlen(sen[senCount]) - 1] = '\0';
        fgets(ans[senCount], MAX_LENGTH, ansFile);
        ans[senCount][strlen(ans[senCount]) - 1] = '\0';
        senCount++;
    }
   
    fclose(senFile);
    fclose(ansFile);
   
    printf("Complete the sentences:\n\n");
	printf("Please Write the sentence using the words differentiating between uppercase and lowercase:\n\n");
    srand(time(NULL));
    int indices[MAX_SEN];
    for (int i = 0; i < senCount; i++) {
        indices[i] = i;
    }
    for (int i = senCount - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = indices[i];
        indices[i] = indices[j];
        indices[j] = temp;
    }

    int correctCount = 0;
    struct Nodo* p;
    p = (struct Nodo*)malloc(sizeof(struct Nodo));
    p->score = 0;
    fflush(stdin);
    for (int i = 0; i < 10; i++) {
        int index = indices[i];
        printf("%d. %s\n", i+1, sen[index]);
        printf("Your answer: ");
        fgets(playerAns[index], MAX_LENGTH, stdin);
        playerAns[index][strlen(playerAns[index]) - 1] = '\0';
        printf("\n");

        if (strcmp(playerAns[index], ans[index]) == 0) {
            printf("%d. %s\nYour answer: %s\n�Correct!\n\n", i+1, sen[index], playerAns[index]);
            correctCount++;
            p->score += 10;
        } else {
            printf("%d. %s\nYour answer: %s\nCorrect answer: %s\n\n", i+1, sen[index], playerAns[index], ans[index]);
        }
    }
    printf(" You did it.\n");
    printf(" Your score: %d\n", p->score);
    printf(" %d of %d Correct answers.\n", correctCount, 10);
    fflush(stdin);
    validaCadena("Enter your name: ",p->nom);
    FILE* scoreFile = fopen("scoreOrder.txt","a");
    fprintf(scoreFile, "%s %d\n", p->nom, p->score);
    fclose(scoreFile);
    free(p);
    return ;
}

void juegoOrdenar() {
    int opcion,i;
    do {
        system("cls");
        printf("\n\t\t\t\tORDERWORD GAME\n\n");
        printf(" OPTIONS:\n\n");
        printf(" 1. Play\n");
        printf(" 2. Scoreboard\n");
        printf(" 3. Exit\n");
        opcion = validaEntero("\n\n Choose one: ");
    } while (opcion < 1 || opcion > 3);

    switch(opcion) {
        case 1:
            orderword();
            juegoOrdenar();
            break;
        case 2:
            scoreOrder();
            system("pause");
            system("cls");
            break;
        case 3:
            printf("\n---------------------------------\n");
            printf("     See You Next Time :D");
            printf("\n---------------------------------\n");
            system("pause");
            system("cls");
            gameMenu();
            break;
        default:
            printf("Invalid option");
                  return;
            break;
    }
}

void dibujo (int intentos){
	switch(intentos){
		case 0:
			printf("\n     _______\n    |       |\n    |\n    |\n    |\n    |\n    |\n ----------");
			break;
		case 1:
			printf("\n     _______\n    |       |\n    |       0\n    |\n    |\n    |\n    |\n ----------");
			break;
		case 2:
			printf("\n     _______\n    |       |\n    |       0\n    |       |\n    |\n    |\n    |\n ----------");
			break;
		case 3:
			printf("\n     _______\n    |       |\n    |       0\n    |      /|\n    |\n    |\n    |\n ----------");
			break;
		case 4:
			printf("\n     _______\n    |       |\n    |       0\n    |      /|");
			printf("\\");
			printf("\n");
			printf("    |\n    |\n    |\n ----------");
			break;
		case 5:
			printf("\n     _______\n    |       |\n    |       0\n    |      /|");
			printf("\\");
			printf("\n");
			printf("    |      /\n    |\n    |\n ----------");
			break;
		case 6:
			printf("\n     _______\n    |       |\n    |       0\n    |      /|");
			printf("\\");
			printf("\n");
			printf("    |      / ");
			printf("\\");
			printf("\n");
			printf("    |\n    |\n ----------");
			break;
	}
}

void playerHang(char *nombre, int puntos) {
    FILE *archivo;
    struct Nodo *nuevo, *actual, *anterior;
    nuevo = (struct Nodo*)malloc(sizeof(struct Nodo));
    if (nuevo == NULL) {
        printf("Memory allocation error");
        exit(1);
    }

    archivo = fopen("scoreHang.txt", "a");
    if (archivo == NULL) {
        printf("Error opening file");
        exit(1);
    }

    //printf("\n\nEnter your name: ");
    fflush(stdin);
    validaCadena("Enter your name: ",nuevo->nom);
    //scanf("%s", nuevo->nom);
    nuevo->score = puntos;
    nuevo->sig = NULL;

    if (*nombre == '\0') {
        strcpy(nombre, nuevo->nom);
        actual = nuevo;
    } else {
        actual = anterior = (struct Nodo*)malloc(sizeof(struct Nodo));
        actual->score = nuevo->score;
        strcpy(actual->nom, nuevo->nom);
        actual->sig = NULL;

        while ((actual != NULL) && (strcmp(actual->nom, nombre) > 0)) {
            anterior = actual;
            actual = actual->sig;
        }
        if (anterior == actual) {
            nuevo->sig = actual;
            actual = nuevo;
        } else {
            anterior->sig = nuevo;
            nuevo->sig = actual;
        }
    }

    fprintf(archivo, "%s\t%i\n", nuevo->nom, nuevo->score);
    fclose(archivo);
}

void scoreHang() {
    FILE *archivo;
    struct Nodo *lista = NULL, *actual = NULL;
    int i = 1;
	printf("\n\t\t\t\tSCOREBOARD\n\n");
    archivo = fopen("scoreHang.txt", "r");
    if (archivo == NULL) {
        printf("Error opening file");
        exit(1);
    }

    // Leer datos del archivo y agregar a lista enlazada
    char nom[20];
    int score;
    while (fscanf(archivo, "%s %i", nom, &score) == 2) {
        struct Nodo *nuevo = (struct Nodo*) malloc(sizeof(struct Nodo));
        strcpy(nuevo->nom, nom);
        nuevo->score = score;
        nuevo->sig = NULL;

        if (lista == NULL) {
            lista = nuevo;
        } else {
            actual = lista;
            while (actual->sig != NULL) {
                actual = actual->sig;
            }
            actual->sig = nuevo;
        }
    }

    fclose(archivo);

    // Ordenar lista por orden alfab�tico
    struct Nodo *temp1 = NULL, *temp2 = NULL;
    char tempNom[20];
    int tempScore;
    for (actual = lista; actual != NULL; actual = actual->sig) {
        for (temp1 = actual->sig; temp1 != NULL; temp1 = temp1->sig) {
            if (strcmp(temp1->nom, actual->nom) < 0) {
                strcpy(tempNom, temp1->nom);
                tempScore = temp1->score;

                strcpy(temp1->nom, actual->nom);
                temp1->score = actual->score;

                strcpy(actual->nom, tempNom);
                actual->score = tempScore;
            }
        }
    }

    // Mostrar tabla por orden alfab�tico
    printf("Scoreboard by NAME:\n");
    printf("+----+----------------------+-------+\n");
    printf("| %-2s | %-20s | %-5s |\n", "No.", "Name", "Score");
    printf("+----+----------------------+-------+\n");
    actual = lista;
    while (actual != NULL) {
        printf("| %-2d | %-20s | %5d |\n", i, actual->nom, actual->score);
        actual = actual->sig;
        i++;
    }
    printf("+----+----------------------+-------+\n");

    // Ordenar lista por puntaje de mayor a menor
    for (actual = lista; actual != NULL; actual = actual->sig) {
        for (temp1 = actual->sig; temp1 != NULL; temp1 = temp1->sig) {
            if (temp1->score > actual->score) {
                tempScore = temp1->score;
                strcpy(tempNom, temp1->nom);

                temp1->score = actual->score;
                strcpy(temp1->nom, actual->nom);

                actual->score = tempScore;
                strcpy(actual->nom, tempNom);
            }
        }
    }
    // Mostrar tabla por puntaje de mayor a menor
        // Mostrar tabla por puntaje de mayor a menor
    printf("\nScoreboard by SCORE:\n");
    printf("+----+----------------------+-------+\n");
    printf("| %-2s | %-20s | %-5s |\n", "No.", "Name", "Score");
    printf("+----+----------------------+-------+\n");
    i = 1;
    actual = lista;
    while (actual != NULL) {
        printf("| %-2d | %-20s | %5d |\n", i, actual->nom, actual->score);
        actual = actual->sig;
        i++;
    }
    printf("+----+----------------------+-------+\n");

    // Liberar memoria de la lista enlazada
    struct Nodo *temp;
    while (lista != NULL) {
        temp = lista;
        lista = lista->sig;
        free(temp);
    }
}

void scoreSen() {
    FILE *archivo;
    struct Nodo *lista = NULL, *actual = NULL;
    int i = 1;
	printf("\n\t\t\t\tSCOREBOARD\n\n");
    archivo = fopen("scoreSen.txt", "r");
    
    if (archivo == NULL) {
        printf("Error opening file");
        exit(1);
    }

    // Leer datos del archivo y agregar a lista enlazada
    char nom[20];
    int score;
    while (fscanf(archivo, "%s %i", nom, &score) == 2) {
        struct Nodo *nuevo = (struct Nodo*) malloc(sizeof(struct Nodo));
        strcpy(nuevo->nom, nom);
        nuevo->score = score;
        nuevo->sig = NULL;

        if (lista == NULL) {
            lista = nuevo;
        } else {
            actual = lista;
            while (actual->sig != NULL) {
                actual = actual->sig;
            }
            actual->sig = nuevo;
        }
    }

    fclose(archivo);

    // Ordenar lista por orden alfab�tico
    struct Nodo *temp1 = NULL, *temp2 = NULL;
    char tempNom[20];
    int tempScore;
    for (actual = lista; actual != NULL; actual = actual->sig) {
        for (temp1 = actual->sig; temp1 != NULL; temp1 = temp1->sig) {
            if (strcmp(temp1->nom, actual->nom) < 0) {
                strcpy(tempNom, temp1->nom);
                tempScore = temp1->score;

                strcpy(temp1->nom, actual->nom);
                temp1->score = actual->score;

                strcpy(actual->nom, tempNom);
                actual->score = tempScore;
            }
        }
    }

    // Mostrar tabla por orden alfab�tico
    printf("Scoreboard by NAME:\n");
    printf("+----+----------------------+-------+\n");
    printf("| %-2s | %-20s | %-5s |\n", "No.", "Name", "Score");
    printf("+----+----------------------+-------+\n");
    actual = lista;
    while (actual != NULL) {
        printf("| %-2d | %-20s | %5d |\n", i, actual->nom, actual->score);
        actual = actual->sig;
        i++;
    }
    printf("+----+----------------------+-------+\n");

    // Ordenar lista por puntaje de mayor a menor
    for (actual = lista; actual != NULL; actual = actual->sig) {
        for (temp1 = actual->sig; temp1 != NULL; temp1 = temp1->sig) {
            if (temp1->score > actual->score) {
                tempScore = temp1->score;
                strcpy(tempNom, temp1->nom);

                temp1->score = actual->score;
                strcpy(temp1->nom, actual->nom);

                actual->score = tempScore;
                strcpy(actual->nom, tempNom);
            }
        }
    }
    // Mostrar tabla por puntaje de mayor a menor
        // Mostrar tabla por puntaje de mayor a menor
    printf("\nScoreboard by SCORE:\n");
    printf("+----+----------------------+-------+\n");
    printf("| %-2s | %-20s | %-5s |\n", "No.", "Name", "Score");
    printf("+----+----------------------+-------+\n");
    i = 1;
    actual = lista;
    while (actual != NULL) {
        printf("| %-2d | %-20s | %5d |\n", i, actual->nom, actual->score);
        actual = actual->sig;
        i++;
    }
    printf("+----+----------------------+-------+\n");

    // Liberar memoria de la lista enlazada
    struct Nodo *temp;
    while (lista != NULL) {
        temp = lista;
        lista = lista->sig;
        free(temp);
    }
}

void scoreOrder() {
    FILE *archivo;
    struct Nodo *lista = NULL, *actual = NULL;
    int i = 1;
	printf("\n\t\t\t\tSCOREBOARD\n\n");
    archivo = fopen("scoreOrder.txt", "r");
    
    if (archivo == NULL) {
        printf("Error opening file");
        exit(1);
    }

    // Leer datos del archivo y agregar a lista enlazada
    char nom[20];
    int score;
    while (fscanf(archivo, "%s %i", nom, &score) == 2) {
        struct Nodo *nuevo = (struct Nodo*) malloc(sizeof(struct Nodo));
        strcpy(nuevo->nom, nom);
        nuevo->score = score;
        nuevo->sig = NULL;

        if (lista == NULL) {
            lista = nuevo;
        } else {
            actual = lista;
            while (actual->sig != NULL) {
                actual = actual->sig;
            }
            actual->sig = nuevo;
        }
    }

    fclose(archivo);

    // Ordenar lista por orden alfab�tico
    struct Nodo *temp1 = NULL, *temp2 = NULL;
    char tempNom[20];
    int tempScore;
    for (actual = lista; actual != NULL; actual = actual->sig) {
        for (temp1 = actual->sig; temp1 != NULL; temp1 = temp1->sig) {
            if (strcmp(temp1->nom, actual->nom) < 0) {
                strcpy(tempNom, temp1->nom);
                tempScore = temp1->score;

                strcpy(temp1->nom, actual->nom);
                temp1->score = actual->score;

                strcpy(actual->nom, tempNom);
                actual->score = tempScore;
            }
        }
    }

    // Mostrar tabla por orden alfab�tico
    printf("Scoreboard by NAME:\n");
    printf("+----+----------------------+-------+\n");
    printf("| %-2s | %-20s | %-5s |\n", "No.", "Name", "Score");
    printf("+----+----------------------+-------+\n");
    actual = lista;
    while (actual != NULL) {
        printf("| %-2d | %-20s | %5d |\n", i, actual->nom, actual->score);
        actual = actual->sig;
        i++;
    }
    printf("+----+----------------------+-------+\n");

    // Ordenar lista por puntaje de mayor a menor
    for (actual = lista; actual != NULL; actual = actual->sig) {
        for (temp1 = actual->sig; temp1 != NULL; temp1 = temp1->sig) {
            if (temp1->score > actual->score) {
                tempScore = temp1->score;
                strcpy(tempNom, temp1->nom);

                temp1->score = actual->score;
                strcpy(temp1->nom, actual->nom);

                actual->score = tempScore;
                strcpy(actual->nom, tempNom);
            }
        }
    }
    // Mostrar tabla por puntaje de mayor a menor
        // Mostrar tabla por puntaje de mayor a menor
    printf("\nScoreboard by SCORE:\n");
    printf("+----+----------------------+-------+\n");
    printf("| %-2s | %-20s | %-5s |\n", "No.", "Name", "Score");
    printf("+----+----------------------+-------+\n");
    i = 1;
    actual = lista;
    while (actual != NULL) {
        printf("| %-2d | %-20s | %5d |\n", i, actual->nom, actual->score);
        actual = actual->sig;
        i++;
    }
    printf("+----+----------------------+-------+\n");

    // Liberar memoria de la lista enlazada
    struct Nodo *temp;
    while (lista != NULL) {
        temp = lista;
        lista = lista->sig;
        free(temp);
    }
}
void empezarJuego(char **palabras, char *nombre, int cantidad_palabras) {
    int opcion, i, j, k, longitud, espacios, puntos = 0;
    char letra;
    int aciertos = 0;
    int intentos = 0;
    int ganar = 0;
    srand(time(NULL));
    opcion = rand() % cantidad_palabras;
	longitud = strlen(palabras[opcion]); 
	char frase[longitud+1];
	frase[longitud] = '\0';
	i = rand() % longitud;
	for (j = 0; j < longitud; j++) {
	    if (j == i) {
	        frase[j] = palabras[opcion][j];
	    } else {
	        frase[j] = '_';
	    }
	}

    do {
        aciertos = 0;
        system("cls");
        printf("\n\t\t\t\tHANGMAN GAME\n\n");
        printf(" Tries: %i\t\t\t\tScore: %i\n\n", 6 - intentos, puntos);
        dibujo(intentos);
        printf("\n\n\n");
        for (i = 0; i < longitud; i++) {
            printf(" %c ", frase[i]);
        }
        if (intentos == 6) {
            printf("\n\n YOU LOSE!!\n");
            printf(" SOLUTION: %s\n\n", palabras[opcion]);
            playerHang(nombre, puntos);
            printf(" PRESS ANY KEY..");
            getch();
            categorias();
        }
        espacios = 0;
        for (i = 0; i < longitud; i++) {
            if (frase[i] == '_')
                espacios++;
        }
        if (espacios == 0) {
            printf("\n\n YOU WIN!!\n\n");
            playerHang(nombre, puntos);
            printf(" PRESS ANY KEY..");
            getch();
            categorias();
        }
        printf("\n\n Letter: ");
        scanf(" %c", &letra);
        for (j = 0; j < longitud; j++) {
            if (letra == palabras[opcion][j]) {
                frase[j] = letra;
                aciertos++;
            }
        }
        if (aciertos > 0) {            
            puntos += aciertos * 10;
        }
        else {
            intentos++;
        }
    } while (intentos != 7);
    printf("\n\n");
}

void categorias() {
    char categoria[20];
    int opcion, cantidad_palabras = 0, i;
    char **palabras;
    FILE *archivo;
	
    do {
        system("cls");
        printf("\n\t\t\t\tHANGMAN GAME\n\n");
        printf(" OPTIONS:\n\n");
        printf(" 1. Play\n");
        printf(" 2. Scoreboard\n");
        printf(" 3. Exit\n");
        opcion = validaEntero("\n\n Choose one: ");
    } while (opcion < 1 || opcion > 3);

    switch(opcion) {
        case 1:
        	for(int i=0; i<10; i++){
        		strcpy(categoria, "hangman.txt");
			}
            break;
        case 2:
        	system("cls");
        	scoreHang();
        	system("pause");
        	categorias();
        	break;
        case 3:
        	printf("\n---------------------------------\n");
            printf("     See You Next Time :D");
            printf("\n---------------------------------\n");
            system("pause");
            system("cls");
            gameMenu();
        	break;
        default:
        	printf("Invalid option");
			return;
        	break;
    }

    archivo = fopen(categoria, "r");
    if (archivo == NULL) {
        printf("\n\n Error opening file.");
        exit(1);
    }

    while (!feof(archivo)) {
        char c = fgetc(archivo);
        if (c == '\n') {
            cantidad_palabras++;
        }
    }
    rewind(archivo);

    palabras = (char **) malloc(cantidad_palabras * sizeof(char *));
    for (i = 0; i < cantidad_palabras; i++) {
        palabras[i] = (char *) malloc(50 * sizeof(char));
        fgets(palabras[i], 50, archivo);
        palabras[i][strlen(palabras[i]) - 1] = '\0'; // Eliminamos el salto de l�nea final
    }

    fclose(archivo);

    empezarJuego(palabras, categoria, cantidad_palabras);
}

void header(){
	printf("Nombre: Jose Rodrigo Bravo Llanas\n");
	printf("Matricula: 178678\n");
	printf("Nombre: Jonathan Guadalupe Ramos Torralba\n");
	printf("Matricula: 177935\n");
	printf("Carrera: Ingenieria en Tecnologias de la Informacion\n");
	printf("Aprendiendo Ingles\n");
	system("pause");
	system("cls");
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

void completeSentence(){
	system("cls");
	char sen[MAX_SEN][MAX_LENGTH];
    char ans[MAX_SEN][MAX_LENGTH];
    char playerAns[MAX_SEN][MAX_LENGTH];
    int senCount = 0;
    
    FILE* senFile = fopen("complete.txt", "r");
    if (senFile == NULL) {
        printf("Error opening file.\n");
        return ;
    }
    
    FILE* ansFile = fopen("answers.txt", "r");
    if (ansFile == NULL) {
        printf("Error opening file.\n");
        return ;
    }
    
    while (fgets(sen[senCount], MAX_LENGTH, senFile) != NULL) {
        sen[senCount][strlen(sen[senCount]) - 1] = '\0';
        fgets(ans[senCount], MAX_LENGTH, ansFile);
        ans[senCount][strlen(ans[senCount]) - 1] = '\0';
        senCount++;
    }
    
    fclose(senFile);
    fclose(ansFile);
    
    printf("Complete the sentences:\n\n");
    printf("Please write the words (not the letter):\n\n");

    srand(time(NULL));
    int indices[MAX_SEN];
    for (int i = 0; i < senCount; i++) {
        indices[i] = i;
    }
    for (int i = senCount - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        int temp = indices[i];
        indices[i] = indices[j];
        indices[j] = temp;
    }

    int correctCount = 0;
    struct Nodo* p;
    //p = malloc(sizeof(struct Nodo));
    p = (struct Nodo*)malloc(sizeof(struct Nodo));
    
    p->score = 0;
    fflush(stdin);
    for (int i = 0; i < 10; i++) {
        int index = indices[i];
        printf("%d. %s\n", i+1, sen[index]);
        printf("Your answer: ");
        fgets(playerAns[index], MAX_LENGTH, stdin);
        playerAns[index][strlen(playerAns[index]) - 1] = '\0';
        printf("\n");

        if (strcmp(playerAns[index], ans[index]) == 0) {
            printf("%d. %s\nYour answer: %s\n�Correct!\n\n", i+1, sen[index], playerAns[index]);
            correctCount++;
            p->score += 10;
        } else {
            printf("%d. %s\nYour answer: %s\nCorrect answer: %s\n\n", i+1, sen[index], playerAns[index], ans[index]);
        }
    }
    printf(" You did it.\n");
    printf(" Your score: %d\n", p->score);
    printf(" %d of %d Correct answers.\n", correctCount, 10);
    fflush(stdin);
    validaCadena("Enter your name: ",p->nom);
    FILE* scoreFile = fopen("scoreSen.txt","a");
    fprintf(scoreFile, "%s %d\n", p->nom, p->score);
    fclose(scoreFile);
    free(p);
    
    return ;
}

void juegoCompletar() {
    int opcion,i;
    do {
        system("cls");
        printf("\n\t\t\t\tCOMPLETE GAME\n\n");
        printf(" OPTIONS:\n\n");
        printf(" 1. Play\n");
        printf(" 2. Scoreboard\n");
        printf(" 3. Exit\n");
        opcion = validaEntero("\n\n Choose one: ");
    } while (opcion < 1 || opcion > 3);

    switch(opcion) {
        case 1:
        	system("cls");
            completeSentence();
            system("pause");
        	juegoCompletar();
            break;
        case 2:
        	system("cls");
        	scoreSen();
        	system("pause");
        	juegoCompletar();
        	break;
        case 3:
        	printf("\n---------------------------------\n");
            printf("     See You Next Time :D");
            printf("\n---------------------------------\n");
            system("pause");
            system("cls");
            gameMenu();
        	break;
        default:
        	printf("Invalid option");
			return;
        	break;
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

void gameMenu(){
	int opc;
	do{
		printf("---------------------------------\n");
		printf("\tChoose a Game\n");
		printf("---------------------------------\n\n");
		printf("   1.- Hangman\n");
		printf("   2.- Complete the Sentence\n");
		printf("   3.- Order Words\n");
		printf("   4.- Exit\n");
		opc = validaEntero("Option: ");
		
		switch(opc){
			case 1:
				for(int i=0; i<10; i++){
					categorias();
					system("pause");
	            	system("cls");
				}
	            break;
            case 2:
            	juegoCompletar();
            	system("pause");
            	system("cls");
            	break;
            case 3:
            	juegoOrdenar();
            	system("pause");
            	system("cls");
            	break;
            case 4:
            	printf("\n---------------------------------\n");
            	printf("     See You Next Time :D");
            	printf("\n---------------------------------\n");
            	system("pause");
            	system("cls");
            	mainMenu();
            	break;
            default:
            	printf("\n---------------------------------\n");
            	printf("\tInvalid Option!\n");
            	printf("---------------------------------\n");
                system("pause");
                system("cls");
		}
	}while(opc != 4);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

void showHangman(){
	FILE *fp;
  	char linea[100];
	system("cls");
  	printf("\n\n---------------------------------\n");
	printf("  Showing the full list: Hangman");
	printf("\n---------------------------------\n\n");
  	// Abrimos el archivo en modo de lectura
  	fp = fopen("hangman.txt", "r");
  	if (fp == NULL) {
    	printf("Error: no se pudo abrir el archivo.\n");
    	return;
  	}

  	// Leemos y mostramos cada l�nea del archivo
  	while (fgets(linea, 100, fp) != NULL) {
    	printf("%s", linea);
  	}

  	// Cerramos el archivo
  	fclose(fp);
  	printf("\n\n");
}

void showCtS(){
	FILE *fp;
	FILE *fp2;
  	char linea[100];
	system("cls");
  	printf("\n\n-------------------------------------------------\n");
	printf("   Showing the full list: Complete the sentences");
	printf("\n---------------------------------------------------\n\n");
  	// Abrimos el archivo en modo de lectura
  	fp = fopen("complete.txt", "r");
  	if (fp == NULL) {
    	printf("Error: no se pudo abrir el archivo.\n");
    	return;
  	}

  	// Leemos y mostramos cada l�nea del archivo
  	while (fgets(linea, 100, fp) != NULL) {
    	printf("%s", linea);
  	}

  	// Cerramos el archivo
  	fclose(fp);
  	printf("\n");
  	
  	printf("\n\n-------------------------------------------------\n");
	printf("   Showing the full list: Complete the sentences answers");
	printf("\n---------------------------------------------------\n\n");
  	fp2 = fopen("answers.txt", "r");
  	if (fp2 == NULL) {
    	printf("Error: no se pudo abrir el archivo.\n");
    	return;
  	}

  	// Leemos y mostramos cada l�nea del archivo
  	while (fgets(linea, 100, fp2) != NULL) {
    	printf("%s", linea);
  	}

  	// Cerramos el archivo
  	fclose(fp2);
  	printf("\n");
}

void showOrderW(){
	FILE *fp;
	FILE *fp2;
  	char linea[100];
	system("cls");
  	printf("\n\n-------------------------------------------\n");
	printf("   Showing the full list: Order words");
	printf("\n---------------------------------------------\n\n");
  	// Abrimos el archivo en modo de lectura
  	fp = fopen("ordenar.txt", "r");
  	if (fp == NULL) {
    	printf("Error: no se pudo abrir el archivo.\n");
    	return;
  	}

  	// Leemos y mostramos cada l�nea del archivo
  	while (fgets(linea, 100, fp) != NULL) {
    	printf("%s", linea);
  	}

  	// Cerramos el archivo
  	fclose(fp);
  	printf("\n");
  	
  	printf("\n\n-------------------------------------------------\n");
	printf("   Showing the full list: Order the sentences answers");
	printf("\n---------------------------------------------------\n\n");
  	fp2 = fopen("ordenarRes.txt", "r");
  	if (fp2 == NULL) {
    	printf("Error: no se pudo abrir el archivo.\n");
    	return;
  	}

  	// Leemos y mostramos cada l�nea del archivo
  	while (fgets(linea, 100, fp2) != NULL) {
    	printf("%s", linea);
  	}

  	// Cerramos el archivo
  	fclose(fp2);
  	printf("\n");
}

void addHangman(){
	char oracion[100];

  	// Abrimos el archivo en modo append
  	FILE *fp = fopen("hangman.txt", "a");

  	if (fp == NULL) {
    	printf("Error: Could not open this file.\n");
    return;
  	}

  	// Pedimos al usuario que ingrese la nueva oraci�n
  	
  	fflush(stdin);
  	validaCadena("Enter the new word:\n",oracion);
//  fgets(oracion, 100, stdin);

  	// Escribimos la nueva oraci�n en el archivo
  	fprintf(fp, "\n%s", oracion);
  	
  	printf("\nNew word added.\n\n");

  	// Cerramos el archivo
  	fclose(fp);
}

void addCtS() {
    char oracion[100],ans[100];
    FILE *fp = fopen("complete.txt", "a");

    if (fp == NULL) {
        printf("Error: Could not open this file.\n");
        return;
    }

    printf("Enter the new word: ");
    fflush(stdin); // Limpiar buffer de entrada
    fgets(oracion, sizeof(oracion), stdin);

    size_t len = strlen(oracion);
    if (len > 0 && oracion[len-1] == '\n') {
        oracion[len-1] = '\0';
    }

    fprintf(fp, "\n%s", oracion);
    printf("\nNew word added.\n\n");

    fclose(fp);
    FILE *fp2 = fopen("answers.txt", "a");

    if (fp2 == NULL) {
        printf("Error: Could not open this file.\n");
        return;
    }

    printf("Answer: ");
    fflush(stdin); // Limpiar buffer de entrada
    fgets(ans, sizeof(ans), stdin);

    size_t len2 = strlen(ans);
    if (len2 > 0 && ans[len2-1] == '\n') {
        ans[len2-1] = '\0';
    }

    fprintf(fp2, "\n%s", ans);
    printf("\nNew word added.\n\n");

    fclose(fp2);
}


void addOrderW(){
	char oracion[100];
	char respuesta[100];
    FILE *fp = fopen("ordenar.txt", "a");
    FILE *fp2 = fopen("ordenarRes.txt", "a");

    if (fp == NULL) {
        printf("Error: Could not open this file.\n");
        return;
    }
     if (fp2 == NULL) {
        printf("Error: Could not open this file.\n");
        return;
    }


    printf("Enter the new word: ");
    fflush(stdin); // Limpiar buffer de entrada
    fgets(oracion, sizeof(oracion), stdin);

    size_t len = strlen(oracion);
    if (len > 0 && oracion[len-1] == '\n') {
        oracion[len-1] = '\0';
    }
    
	printf("Enter the answer: ");
    fflush(stdin); // Limpiar buffer de entrada
    fgets(respuesta, sizeof(respuesta), stdin);

    size_t lan = strlen(respuesta);
    if (len > 0 && oracion[len-1] == '\n') {
        oracion[len-1] = '\0';
    }
    
    

    fprintf(fp, "\n%s", oracion);
    fprintf(fp2, "\n%s", respuesta);
    printf("\nNew word added.\n\n");

    fclose(fp);
    fclose(fp2);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void administrador() {
  	int opc;
  	// Pedimos las credenciales de usuario
  	char username[20], password[20];
  	do {
		system("cls");
  		printf("\n---------------------------------\n");
		printf("\tWelcome Administrator");
		printf("\n---------------------------------\n\n");
	  	printf("Username: ");
		scanf("%s", username);
		printf("Password: ");
		scanf("%s", password);
		
		// Verificamos si las credenciales son correctas
		if (strcmp(username, "admin") == 0 && strcmp(password, "1234") == 0) {
			do {
				system("cls");
				printf("\n---------------------------------\n");
				printf("\tWelcome Administrator");
				printf("\n---------------------------------\n");
				printf("\tChoose an option");
				printf("\n---------------------------------\n\n");
				printf("   1.- Show Hangman file\n");
				printf("   2.- Show Complete the sentences file\n");
				printf("   3.- Show Order words file\n");
				printf("   4.- Add new word to Hangman file\n");
				printf("   5.- Add new sentence to Complete the sentences file\n");
				printf("   6.- Add new sentence to Order words file\n");
				printf("   7.- Log out\n\n");
				opc = validaEntero("Option: ");
				switch(opc) {
					case 1:
						showHangman();
						system("pause");
						break;
					case 2:
						showCtS();
						system("pause");
						break;
					case 3:
						showOrderW();
						system("pause");
						break;
					case 4:
						addHangman();
						system("pause");
						break;
					case 5:
						addCtS();
						system("pause");
						break;
					case 6:
						addOrderW();
						system("pause");
						break;
					case 7:
						system("cls");
						mainMenu();
						break;
					default:
						printf("Error: '%d' is not a valid number.\n", opc);
						break;
				}
			} while (opc != 0);
		} else {
			printf("Incorrect credentials. Try again.\n\n");
			system("pause");
		}
	} while(strcmp(username, "admin") != 0 || strcmp(password, "1234") != 0);
	system("cls");
	administrador();
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mainMenu(){
	int opc;
	printf("\n---------------------------------\n");
    printf("\tWelcome");
    printf("\n---------------------------------\n\n");
    printf("  1.- Administrator\n");
    printf("  2.- Player\n");
    printf("  3.- Exit\n");
    opc = validaEntero("Option: ");
    switch(opc){
        case 1:
            administrador();		    
            break;
        case 2:
        	system("cls");
            gameMenu();
            break;
        case 3:
			printf("\n---------------------------------\n");
            printf("     See You Next Time :D");
            printf("\n---------------------------------\n");
            system("pause");
            system("cls");
			exit(1);
        default:
            printf("Error: '%d' is not a valid number.\n", opc);
            mainMenu(); // Volver a mostrar el menu
            break;
    }
}

int main(){
	header();
	mainMenu();
}
